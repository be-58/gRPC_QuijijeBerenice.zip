from concurrent import futures
import grpc
import user_service_pb2
import user_service_pb2_grpc

class UserService(user_service_pb2_grpc.UserServiceServicer):
    def __init__(self):
        self.users = {
            "1": {"name": "John Doe", "email": "john@example.com"},
            "2": {"name": "Jane Smith", "email": "jane@example.com"}
        }
    
    def GetUser(self, request, context):
        user_id = request.user_id
        if user_id in self.users:
            user = self.users[user_id]
            return user_service_pb2.UserResponse(
                user_id=user_id,
                name=user["name"],
                email=user["email"]
            )
        context.set_code(grpc.StatusCode.NOT_FOUND)
        context.set_details("User not found")
        return user_service_pb2.UserResponse()
    
    def CreateUser(self, request, context):
        new_id = str(len(self.users) + 1)
        self.users[new_id] = {
            "name": request.name,
            "email": request.email
        }
        return user_service_pb2.CreateUserResponse(
            user_id=new_id,
            success=True
        )
    
    def ListUsers(self, request, context):
        users_list = []
        for user_id, user_data in self.users.items():
            users_list.append(user_service_pb2.UserResponse(
                user_id=user_id,
                name=user_data["name"],
                email=user_data["email"]
            ))
        return user_service_pb2.ListUsersResponse(users=users_list)

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    user_service_pb2_grpc.add_UserServiceServicer_to_server(
        UserService(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server running on port 50051...")
    server.wait_for_termination()

if __name__ == '__main__':
    serve()