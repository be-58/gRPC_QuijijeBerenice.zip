import grpc
import user_service_pb2
import user_service_pb2_grpc

def run():
    channel = grpc.insecure_channel('localhost:50051')
    stub = user_service_pb2_grpc.UserServiceStub(channel)
    
    # Ejemplo de llamadas
    print("--- GetUser ---")
    response = stub.GetUser(user_service_pb2.UserRequest(user_id="1"))
    print(f"User 1: {response.name}, {response.email}")
    
    print("\n--- CreateUser ---")
    new_user = stub.CreateUser(user_service_pb2.CreateUserRequest(
        name="Alice Johnson",
        email="alice@example.com"
    ))
    print(f"New user created with ID: {new_user.user_id}")
    
    print("\n--- ListUsers ---")
    all_users = stub.ListUsers(user_service_pb2.Empty())
    for user in all_users.users:
        print(f"{user.user_id}: {user.name} - {user.email}")

if __name__ == '__main__':
    run()